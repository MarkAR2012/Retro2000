import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess

class DesktopApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RetroEnvironment2000")
        self.root.geometry("800x600")  # Set the window size
        
        self.create_menu()
        self.add_icon("RetroEdit2000.py", "Notepad", "notepad.png")
        self.add_icon("RetroCalc2000.py", "Calculator", "calc.png")
        self.add_icon("RetroClock2000.py", "Clock", "clock.png")
        
    def create_menu(self):
        menu_bar = tk.Menu(self.root)
        
        file_menu = tk.Menu(menu_bar, tearoff=0)
        file_menu.add_command(label="About", command=self.show_about_dialog)
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        menu_bar.add_cascade(label="File", menu=file_menu)
        
        self.root.config(menu=menu_bar)
    
    def show_about_dialog(self):
        about_window = tk.Toplevel(self.root)
        about_window.title("About RetroEnvironment2000")
        about_window.geometry("400x250")  # Adjust window size
        
        # Load and display logo
        try:
            logo = Image.open("icons/logo.png")
            logo = logo.resize((100, 100))
            logo = ImageTk.PhotoImage(logo)
            logo_label = tk.Label(about_window, image=logo)
            logo_label.image = logo  # Keep a reference to prevent garbage collection
            logo_label.pack(pady=10)
        except Exception as e:
            print("Error loading logo:", e)
        
        # Display about text
        about_text = "RetroEnvironment2000\n\nA nostalgic desktop environment\nfor the 21st century."
        about_label = tk.Label(about_window, text=about_text, font=("Helvetica", 12))
        about_label.pack(pady=10)
    
    def add_icon(self, script, name, icon_file):
        try:
            icon = Image.open(f"icons/{icon_file}")
            icon = icon.resize((24, 24))
            icon = ImageTk.PhotoImage(icon)
            button = tk.Button(self.root, text=name, image=icon, compound=tk.LEFT, command=lambda: self.open_program(script))
            button.image = icon  # Keep a reference to prevent garbage collection
            button.pack(side=tk.LEFT, anchor=tk.NW, padx=5, pady=5)
        except Exception as e:
            print(f"Error loading {name} icon:", e)
        
    def open_program(self, script):
        try:
            subprocess.Popen(["python", script])
        except Exception as e:
            print(f"Error opening {script}:", e)

if __name__ == "__main__":
    app = DesktopApp()
    app.root.mainloop()
