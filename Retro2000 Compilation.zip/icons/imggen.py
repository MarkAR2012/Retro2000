from PIL import Image, ImageDraw

# Create a new blank image with white background
width, height = 200, 100
image = Image.new("RGB", (width, height), "white")

# Get a drawing context
draw = ImageDraw.Draw(image)

# Draw the Windows 3.1 logo
draw.rectangle([(20, 20), (180, 80)], fill="#008080", outline="black")  # Blue rectangle
draw.rectangle([(40, 40), (70, 60)], fill="white", outline="black")  # White window frame
draw.rectangle([(90, 40), (160, 60)], fill="white", outline="black")  # White window frame

# Save the image
image.save("logo.png")
