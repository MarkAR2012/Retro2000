import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

class RetroEdit2000:
    def __init__(self, root):
        self.root = root
        self.root.title("RetroEdit2000")
        self.root.configure(bg="#003300")  # Dark green background
        self.create_menu()
        self.create_text_area()
    
    def create_menu(self):
        menu_bar = tk.Menu(self.root, bg="#003300", fg="#00ff00")  # Dark green background, Light green text
        
        file_menu = tk.Menu(menu_bar, tearoff=0, bg="#003300", fg="#00ff00")  # Dark green background, Light green text
        file_menu.add_command(label="New", command=self.new_file)
        file_menu.add_command(label="Open", command=self.open_file)
        file_menu.add_command(label="Save", command=self.save_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.exit_program)
        menu_bar.add_cascade(label="File", menu=file_menu)
        
        edit_menu = tk.Menu(menu_bar, tearoff=0, bg="#003300", fg="#00ff00")  # Dark green background, Light green text
        edit_menu.add_command(label="Cut", command=self.cut_text)
        edit_menu.add_command(label="Copy", command=self.copy_text)
        edit_menu.add_command(label="Paste", command=self.paste_text)
        menu_bar.add_cascade(label="Edit", menu=edit_menu)
        
        self.root.config(menu=menu_bar)
    
    def create_text_area(self):
        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, font=("Courier", 12), bg="#003300", fg="#00ff00")  # Dark green background, Light green text
        self.text_area.pack(expand=True, fill="both", padx=10, pady=10)
    
    def new_file(self):
        self.text_area.delete(1.0, tk.END)
    
    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
                self.text_area.delete(1.0, tk.END)
                self.text_area.insert(1.0, content)
    
    def save_file(self):
        content = self.text_area.get(1.0, tk.END)
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(content)
            messagebox.showinfo("Info", "File saved successfully.")
    
    def exit_program(self):
        self.root.destroy()
    
    def cut_text(self):
        self.text_area.event_generate("<<Cut>>")
    
    def copy_text(self):
        self.text_area.event_generate("<<Copy>>")
    
    def paste_text(self):
        self.text_area.event_generate("<<Paste>>")

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg="#003300")  # Dark green background
    retro_edit = RetroEdit2000(root)
    root.mainloop()
