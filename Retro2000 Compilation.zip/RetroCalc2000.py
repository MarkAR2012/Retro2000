import tkinter as tk

# Function to handle button clicks
def button_click(number):
    current = display_var.get()
    # Check if the current display ends with an operator
    if current.endswith(("+", "-", "*", "/")):
        display_var.set(current + str(number))
    else:
        # Clear the display if the current display is not empty and does not contain a digit
        if not current or not current[-1].isdigit():
            clear_display()
        display_var.set(display_var.get() + str(number))

# Function to clear the display
def clear_display():
    display_var.set("")

# Function to evaluate the expression and display the result
def calculate():
    try:
        result = eval(display_var.get())
        display_var.set(str(result))
    except:
        display_var.set("Error")

# Create the main window
root = tk.Tk()
root.title("RetroCalc 2000")

# Set window size and background color
root.geometry("800x600")
root.configure(bg="green")

# Create display
display_var = tk.StringVar()
display = tk.Entry(root, textvariable=display_var, font=("Courier", 24), justify="right", bd=10, bg="black", fg="green")
display.grid(row=0, column=0, columnspan=4, padx=20, pady=20, sticky="nsew")

# Define button layout
buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("+", 1, 3),
    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("-", 2, 3),
    ("1", 3, 0), ("2", 3, 1), ("3", 3, 2), ("*", 3, 3),
    ("0", 4, 0), ("C", 4, 1), ("=", 4, 2), ("/", 4, 3)
]

# Create buttons
for (text, row, col) in buttons:
    if text == "=":
        button = tk.Button(root, text=text, font=("Courier", 20), padx=40, pady=20, bg="black", fg="green",
                           command=calculate)
    elif text == "C":
        button = tk.Button(root, text=text, font=("Courier", 20), padx=40, pady=20, bg="black", fg="green",
                           command=clear_display)
    else:
        button = tk.Button(root, text=text, font=("Courier", 20), padx=40, pady=20, bg="black", fg="green",
                           command=lambda t=text: button_click(t))
    button.grid(row=row, column=col, padx=10, pady=10)

# Run the main loop
root.mainloop()
