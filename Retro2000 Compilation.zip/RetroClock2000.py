import tkinter as tk
from time import strftime

def update_time():
    current_time = strftime("%H:%M:%S %p")
    clock_label.config(text=current_time)
    clock_label.after(1000, update_time)  # Update every 1000 milliseconds (1 second)

root = tk.Tk()
root.title("RetroClock 2000")
root.geometry("300x100")
root.configure(bg="black")

clock_label = tk.Label(root, font=("Courier", 24), bg="black", fg="green")
clock_label.pack(expand=True, fill="both", padx=20, pady=20)

update_time()  # Start the clock update loop

root.mainloop()
